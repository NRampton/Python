from __future__ import unicode_literals

from django.apps import AppConfig


class TimeDispConfig(AppConfig):
    name = 'time_disp'
